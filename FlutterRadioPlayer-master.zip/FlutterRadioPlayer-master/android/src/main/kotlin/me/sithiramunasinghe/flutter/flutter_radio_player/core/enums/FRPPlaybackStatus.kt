package me.sithiramunasinghe.flutter.flutter_radio_player.core.enums

enum class FRPPlaybackStatus {
    LOADING,
    STOPPED,
    PLAYING,
    PAUSED,
    ERROR
}