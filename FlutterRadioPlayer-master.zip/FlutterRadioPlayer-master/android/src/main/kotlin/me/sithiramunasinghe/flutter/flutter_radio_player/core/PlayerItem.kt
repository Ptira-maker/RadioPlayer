package me.sithiramunasinghe.flutter.flutter_radio_player.core

class PlayerItem(var appName: String, var subTitle: String, var streamUrl: String, var playWhenReady: String, var primaryColor: Int?)