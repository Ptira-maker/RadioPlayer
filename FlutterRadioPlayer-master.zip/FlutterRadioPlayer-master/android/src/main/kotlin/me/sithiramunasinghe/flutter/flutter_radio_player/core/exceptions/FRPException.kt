package me.sithiramunasinghe.flutter.flutter_radio_player.core.exceptions

class FRPException(message: String) : RuntimeException(message)