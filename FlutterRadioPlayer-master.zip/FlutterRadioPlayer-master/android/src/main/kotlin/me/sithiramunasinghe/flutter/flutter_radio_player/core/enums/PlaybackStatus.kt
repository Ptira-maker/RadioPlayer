package me.sithiramunasinghe.flutter.flutter_radio_player.core.enums

enum class PlaybackStatus {
    LOADING, STOPPED, PLAYING, PAUSED, ERROR
}
