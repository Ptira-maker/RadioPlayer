package me.sithiramunasinghe.flutter.flutter_radio_player.core

const val FLUTTER_RADIO_PLAYER_STOPPED = "flutter_radio_stopped"
const val FLUTTER_RADIO_PLAYER_PLAYING = "flutter_radio_playing"
const val FLUTTER_RADIO_PLAYER_PAUSED = "flutter_radio_paused"
const val FLUTTER_RADIO_PLAYER_LOADING = "flutter_radio_loading"

const val FLUTTER_RADIO_PLAYER_ERROR = "flutter_radio_error"