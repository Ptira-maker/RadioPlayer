package me.sithiramunasinghe.flutter_radio_player_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
