#import <Flutter/Flutter.h>

@interface FlutterRadioPlayerPlugin : NSObject<FlutterPlugin>
@end
