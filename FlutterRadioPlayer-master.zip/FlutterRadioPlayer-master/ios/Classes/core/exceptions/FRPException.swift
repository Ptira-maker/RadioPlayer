//
//  FRPException.swift
//  flutter_radio_player
//
//  Created by Sithira Munasinghe on 2022-05-25.
//

import Foundation

enum FRPException: Error {
    case runtimeError(errorMessage: String)
}
