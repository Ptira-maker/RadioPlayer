//
//  FRPVolumeChanageEvent.swift
//  flutter_radio_player
//
//  Created by Sithira Munasinghe on 2022-05-26.
//

import Foundation

struct FRPVolumeChangeEvent: Codable {
    var volume: Float? = 0.5
}
