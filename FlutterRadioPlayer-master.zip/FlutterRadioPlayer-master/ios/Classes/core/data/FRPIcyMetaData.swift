//
//  FRPIcyMetaData.swift
//  flutter_radio_player
//
//  Created by Sithira Munasinghe on 2022-03-09.
//

import Foundation

struct FRPIcyMetaData {
    private var title: String?
    private var artistName: String?
}
